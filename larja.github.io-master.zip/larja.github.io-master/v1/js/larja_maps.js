function LarJaMaps() {
  this.map = null;
  this.markers = [];
  this.imoveis = [];
  this.url = 'https://raw.githubusercontent.com/larja/larja.github.io/master/data/db2.json';
  this.lat = -26.238794799999997;
  this.lng = -52.674876999999995;
  this.xhr = new XMLHttpRequest();
  this.infowindow = new google.maps.InfoWindow({});
  this.styles = [
    {
      stylers: [
        { hue: "#00ffe6" },
        { saturation: -20 }
      ]
    },{
      featureType: "road.arterial",
      elementType: "geometry",
      stylers: [
        { lightness: 100 },
        { visibility: "simplified" }
      ]
    },{
      featureType: "poi.business",
      elementType: "labels",
      stylers: [
        { visibility: "on" }
      ]
    }
  ];
}

LarJaMaps.prototype.carregarEnderecos = function() {
  var self = this;

  $.get(this.url, function(response) {
    self.parseFn(response);
  });
}

LarJaMaps.prototype.parseFn = function(response) {
  var json = JSON.parse(response).data,
      imoveis = json.products,
      imovel = null,
      posicaoImovel = null;

  for (var i = 0; i < imoveis.length; i++) {
    imovel = imoveis[i];

    posicaoImovel = this.getMarkerImovel(imovel.lat, imovel.lng);
    this.addMarker(posicaoImovel, imovel);
    this.imoveis.push(imovel);
  }
}

LarJaMaps.prototype.getMarkerImovel = function(lat, lng) {
  return new google.maps.LatLng(lat, lng);
}

LarJaMaps.prototype.addMarker = function(position, imovel) {
  var self = this;

  var marker = new google.maps.Marker({
    position: position,
    map: self.map,
    animation: google.maps.Animation.DROP
  });

  google.maps.event.addListener(marker, 'click', function() {
    self.infowindow.setContent(self.getDivPopUp(imovel));
    self.infowindow.open(self.map, this);
  });

  this.markers.push(marker);
}

LarJaMaps.prototype.getDivPopUp = function(imovel) {
  console.log( imovel );
  var imageUrl;
  if (imovel.imagem_nome == null){
      imageUrl = imovel.base_image_url + imovel.full_thumbs.split("|")[0];
  }else{
    imageUrl = imovel.base_image_url + imovel.imagem_nome;
  }

  var valor = this.obterValor(imovel);
  var labelValor;

  if (valor > 0){
    labelValor = 'R$ ' + valor;
  }else {
    labelValor = 'Consulte';
  }

  return '<div style="z-index:500"><img src=' + imageUrl+ ' width="240px" height="180px"></img><br/><span class="title">' + imovel.nome + '&nbsp;<br/>' + imovel.nome_empresa + '&nbsp;</span><span class="info2">'+ imovel.area_util +'m²&nbsp;&nbsp;•&nbsp;&nbsp;'+ imovel.quartos +' dorms&nbsp;&nbsp;•&nbsp;&nbsp;' + imovel.garagens + ' vagas&nbsp;</span><span class="price">'+ labelValor +'</span></div>';
}

LarJaMaps.prototype.obterValor = function(imovel) {
  return (imovel.referencia.indexOf("VEN") > 1) ? imovel.valor_venda : imovel.valor_locacao;
}

// Sets the map on all markers in the array.
LarJaMaps.prototype.setMapOnAll = function(map) {
  for (var i = 0; i < this.markers.length; i++) {
    this.markers[i].setMap(map);
  }
}

// Removes the markers from the map, but keeps them in the array.
LarJaMaps.prototype.clearMarkers = function() {
  this.setMapOnAll(null);
}

LarJaMaps.prototype.resetMarkers = function() {
  this.clearMarkers();

  var imoveis = this.imoveis;

  for (var i = 0; i < imoveis.length; i++) {
    imovel = imoveis[i];

    this.addMarker(this.getMarkerImovel(imovel.lat, imovel.lng), imovel);
  }
}

LarJaMaps.prototype.filter = function(opts) {

  if (!opts.comprar && !opts.alugar &&
      opts.imovel == 0 && opts.quartos == 0) {
    return;
  }

  this.clearMarkers();

  this.markers = [];

  var imoveis = this.imoveis,
      imovel = null,
      tipoImovel = null,
      opcaoQuartos = null,
      opcaoComprar = null,
      opcaoAlugar = null;

  var result;

  function vendaOuLocacao(imovel, tipo) {
    if (imovel.referencia.match(tipo) != null) {
      return imovel;
    }
  }

  if (opts.comprar) {
    result = imoveis.filter(function(imovel) {
      return imovel.referencia.match(/^VEN/);
    });
  }

  if (opts.alugar) {
    result = imoveis.filter(function(imovel) {
      return vendaOuLocacao(imovel, /LOC/);
    });
  }

  if (parseInt(opts.imovel) != 0) {
    var match;
    result = result.filter(function(imovel) {
      if (imovel.nome_tipo) {
        console.log( imovel.nome_tipo, opts.imovel, imovel.nome_tipo.toUpperCase().match(opts.imovel));
        match = imovel.nome_tipo.toUpperCase().match(opts.imovel)
        if (match != null)
          return imovel;
      }
    });
  }

  if (opts.quartos > 0) {
    result = result.filter(function(imovel) {
      if (imovel.quartos == opts.quartos) {
        return imovel;
      }
    });
  }

  for (var i = 0; i < result.length; i++) {
    imovel = result[i];
    this.addMarker(this.getMarkerImovel(imovel.lat, imovel.lng), imovel);
  }
}

LarJaMaps.prototype.initialize = function(whichMap) {
  var divMap = document.getElementById(whichMap);
  var pos = new google.maps.LatLng(this.lat, this.lng);
  var mapOptions = {
    zoom: 14,
    center: pos,
    mapTypeControlOptions: {
      mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'map_style']
    }
  }

  this.map = new google.maps.Map(divMap, mapOptions);
  this.carregarEnderecos();
}
