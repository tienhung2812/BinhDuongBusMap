function LarJaMaps() {
  this.map = null;
  this.markers = [];
  this.url = '/data/db.json';
  this.lat = -26.238794799999997;
  this.lng = -52.674876999999995;
  this.xhr = new XMLHttpRequest();
  this.infowindow = new google.maps.InfoWindow({});
  this.styles = [
    {
      stylers: [
        { hue: "#00ffe6" },
        { saturation: -20 }
      ]
    },{
      featureType: "road.arterial",
      elementType: "geometry",
      stylers: [
        { lightness: 100 },
        { visibility: "simplified" }
      ]
    },{
      featureType: "poi.business",
      elementType: "labels",
      stylers: [
        { visibility: "on" }
      ]
    }
  ];
}

LarJaMaps.prototype.carregarEnderecos = function() {
  var self = this;
  this.xhr.onreadystatechange = function(args) {
    if (this.readyState == this.DONE) {
      self.parseFn(this.responseText);
    }
  };
  this.xhr.open("GET", this.url);
  this.xhr.send();
}

LarJaMaps.prototype.parseFn = function(response) {
  var json = JSON.parse(response).data,
  imoveis = json.products,
  imovel = null,
  posicaoImovel = null;

  for (var i = 0; i < imoveis.length; i++) {
    imovel = imoveis[i];
    posicaoImovel = this.getMarkerImovel(imovel.lat, imovel.lng);
    this.addMarker(posicaoImovel, imovel);
  }
}

LarJaMaps.prototype.getMarkerImovel = function(lat, lng) {
  return new google.maps.LatLng(lat, lng);
}

LarJaMaps.prototype.addMarker = function(position, imovel) {
  var self = this;

  var marker = new google.maps.Marker({
    position: position,
    map: self.map,
    animation: google.maps.Animation.DROP
  });

  google.maps.event.addListener(marker, 'click', function() {
    self.infowindow.setContent(self.getDivPopUp(imovel));
    self.infowindow.open(self.map, this);
  });

  this.markers.push(marker);
}

LarJaMaps.prototype.getDivPopUp = function(imovel) {
  return '<div style="z-index:500"><img src=' + imovel.full_imagem_nome + ' width="320px" height="280px"></img><br/><span class="title">' + imovel.nome + '&nbsp;<br/>' + imovel.nome_empresa + '&nbsp;</span><span class="info2">'+ imovel.area_util +'m²&nbsp;&nbsp;•&nbsp;&nbsp;'+ imovel.quartos +' dorms&nbsp;&nbsp;•&nbsp;&nbsp;' + imovel.garagens + ' vagas&nbsp;</span><span class="price">R$ '+ this.obterValor(imovel) +'</span></div>';
}

LarJaMaps.prototype.obterValor = function(imovel) {
  return (imovel.referencia.indexOf("VEN") > 1) ? imovel.valor_venda : imovel.valor_locacao;
}

LarJaMaps.prototype.initialize = function(whichMap) {
  var divMap = document.getElementById(whichMap);
  var styledMap = new google.maps.StyledMapType(this.styles, {name: "Styled Map"});
  var pos = new google.maps.LatLng(this.lat, this.lng);
  var mapOptions = {
    zoom: 14,
    center: pos,
    mapTypeControlOptions: {
      mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'map_style']
    }
  }

  this.map = new google.maps.Map(divMap, mapOptions);
  this.map.mapTypes.set('map_style', styledMap);
  this.map.setMapTypeId('map_style');
  this.carregarEnderecos();
}
