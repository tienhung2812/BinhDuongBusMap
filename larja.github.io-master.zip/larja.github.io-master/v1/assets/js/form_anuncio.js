document.addEventListener("DOMContentLoaded", function(event) {
  var firebase = new Firebase("https://larja.firebaseio.com/anuncios");
  var btn = document.getElementById("btnAds");

  btn.addEventListener("click", function(e) {
    var name = document.getElementById("first_name").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var city = document.getElementById("city").value;

    var type = document.getElementById("type");
    type = type.options[type.selectedIndex].value;

    if (name && email && phone && city && type) {
      firebase.push({
        name: name,
        email: email,
        phone: phone,
        city: city,
        type: type
      });

      document.getElementById("adsForm").innerHTML = 'Obrigado, em breve entraremos em contato!';
    }

    e.preventDefault();
  });

});
